<?php

namespace App\Exceptions\Common;

use Exception;

class NotUserDashboard extends Exception
{
    //
}
