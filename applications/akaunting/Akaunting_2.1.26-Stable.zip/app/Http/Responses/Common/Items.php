<?php

namespace App\Http\Responses\Common;

use App\Abstracts\Http\Response;

class Items extends Response
{
    //
}
