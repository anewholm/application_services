<?php
include ('config.php');
include (APP_BASE_PATH.'fileupload_page.php');
