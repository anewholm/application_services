This module is licensed under IceHrm Commercial License, which can be found in LICENSE.txt.
You are allowed to make any modification required to these module, but only allowed to use
the module in one production server (even with modifications).

Installation
------------
Copy this module into <icehrm path>/admin/ directory