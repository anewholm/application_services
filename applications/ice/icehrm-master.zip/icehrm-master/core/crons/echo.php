<?php
include dirname(__FILE__).'/include.cron.php';
echo "CLIENT_NAME : ".CLIENT_NAME."\r\n";