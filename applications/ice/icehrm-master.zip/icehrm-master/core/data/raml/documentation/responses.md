| Code | Description        |
|------|--------------------|
| 200  | Ok                 |
| 201  | Created            |
| 400  | Bad request        |
| 401  | Not authorized     |
| 403  | Forbidden          |
| 404  | Resource not found |
| 500  | Server error       |