Github issue tracker is used for bug only. 
For general questions, please join the [Google group](https://groups.google.com/forum/#!forum/jorani)

The language used for issue tracker, commit and doc is english
