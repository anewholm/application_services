Github issue tracker is used for bug only. 
For general questions and requests, please join the [Google group](https://groups.google.com/forum/#!forum/jorani)

Don't hesitate to provide screenshots.


### What is the version of Jorani?


### Expected behavior


### Actual behavior


### Steps to reproduce the behavior

